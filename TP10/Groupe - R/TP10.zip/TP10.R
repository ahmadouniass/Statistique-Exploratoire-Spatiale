#====================================================================================#
#     ENSAE Pierre NDIAYE de Dakar ISE1-Cycle long 2024-2025                         #
#     COURS DE Statistique exploratoire spaciale  avec M.Aboubacar HEMA              #
#                           Travaux Pratiques N°10                                   #
#                                                                                    #
#    Groupe : Logiciel R                                                             #
#    Pays : Niger                                                                    #
#    Composé de : FOGWOUNG DJOUFACK Sarah-Laure, NGUEMFOUO NGOUMTSA Célina,          #
#                 NIASS Ahmadou, SENE Malick                                         #                       
#                                                                                    #
#                                                                                    #
#====================================================================================#

#                          ============== CONSIGNE =================
                            # Calcul d'e quelques indices spectraux

# Charger les bibliothèques nécessaires
library(ggplot2)
library(dplyr)
library(leaflet)
library(sf)
library(raster)
library(terra)
library(leaflet.extras)
library(viridis)
library(exactextractr)

#Définir le chemin d'accès des données 
setwd("C:/Users/DELL/Desktop/ISEP3/Statistique ES/TP10")

# Charger le fichier raster
#Ce ficher a été obtenu à partir des dataset disponibles dans GEE en faisant un clip sur le Niger
#puis en exportant les données.
raster_image <- rast("Sentinel2_Niger.tif")

# Afficher les noms des bandes et leurs valeurs
names(raster_image)
print(unique(raster_image))

##################Calcul des indices#######################################
# Calcul de l'AFRI1600
# N = Bande B8, S1 = Bande B11
afri1600 <- (raster_image$B8 - 0.66 * raster_image$B11) /
  (raster_image$B8 + 0.66 * raster_image$B11)
stat(afri1600)

# Calcul de l'AFRI2100
# N = Bande B8, S2 = Bande B12
afri2100 <- (raster_image$B8 - 0.5 * raster_image$B12) /
  (raster_image$B8 + 0.5 * raster_image$B12)
#Caractéristiques de l'indice
stat(afri2100)

# Calcul de l'ANDWI
# B = Bande B2, G = Bande B3, R = Bande B4, N = Bande B8, S1 = Bande B11, S2 = Bande B12
andwi <- (raster_image$B2 + raster_image$B3 + raster_image$B4 -
            raster_image$B8 - raster_image$B11 - raster_image$B12) /
  (raster_image$B2 + raster_image$B3 + raster_image$B4 +
     raster_image$B8 + raster_image$B11 + raster_image$B12)
#Caractéristiques de l'indice
stat(andwi)

# Calcul de l'ARI
# G = Bande B3, RE1 = Bande B5
ari <- (1 / raster_image$B3) - (1 / raster_image$B5)
#Caractéristiques de l'indice
stat(ari)

# Calcul de l'ARI2
# N = Bande B8, G = Bande B3, RE1 = Bande B5
ari2 <- raster_image$B8 * ((1 / raster_image$B3) - (1 / raster_image$B5))
#Caractéristiques de l'indice
stat(ari2)

# Calcul de l'AWEInsh
# G = Bande B3, S1 = Bande B11, N = Bande B8, S2 = Bande B12
aweinsh <- 4.0 * (raster_image$B3 - raster_image$B11) -
  0.25 * raster_image$B8 +
  2.75 * raster_image$B12
#Caractéristiques de l'indice
stat(aweinsh)

# Calcul de l'AWEIsh
# B = Bande B2, G = Bande B3, N = Bande B8, S1 = Bande B11, S2 = Bande B12
aweish <- raster_image$B2 +
  2.5 * raster_image$B3 -
  1.5 * (raster_image$B8 + raster_image$B11) -
  0.25 * raster_image$B12
#Caractéristiques de l'indice
stat(aweish)

# Calcul du BAI
# R = Bande B4, N = Bande B8
bai <- 1.0 / ((0.1 - raster_image$B4)^2 + (0.06 - raster_image$B8)^2)

# Calcul du BAIM
# N = Bande B8, S2 = Bande B12
baim <- 1.0 / ((0.05 - raster_image$B8)^2 + (0.2 - raster_image$B12)^2)

# Calcul du BI
# S1 = Bande B11, R = Bande B4, N = Bande B8, B = Bande B2
bi <- ((raster_image$B11 + raster_image$B4) - (raster_image$B8 + raster_image$B2)) /
  ((raster_image$B11 + raster_image$B4) + (raster_image$B8 + raster_image$B2))

# Calcul du BLFEI
# G = Bande B3, R = Bande B4, S2 = Bande B12, S1 = Bande B11
mean_grs2 <- (raster_image$B3 + raster_image$B4 + raster_image$B12) / 3.0
blfei <- (mean_grs2 - raster_image$B11) / (mean_grs2 + raster_image$B11)

# Calcul du BRBA
# R = Bande B4, S1 = Bande B11
brba <- raster_image$B4 / raster_image$B11

# Calcul du BNDVI
# N = Bande B8, B = Bande B2
bndvi <- (raster_image$B8 - raster_image$B2) / (raster_image$B8 + raster_image$B2)

# DBSI (Dry Bareness Index)
# S1 = Bande B11, G = Bande B3, N = Bande B8, R = Bande B4
dbsi <- ((raster_image$B11 - raster_image$B3) / (raster_image$B11 + raster_image$B3)) - 
  ((raster_image$B8 - raster_image$B4) / (raster_image$B8 + raster_image$B4))

# DSI (Drought Stress Index)
# S1 = Bande B11, N = Bande B8
dsi <- raster_image$B11 / raster_image$B8

# DSWI1 (Disease-Water Stress Index 1)
# N = Bande B8, S1 = Bande B11
dswi1 <- raster_image$B8 / raster_image$B11

# DSWI2 (Disease-Water Stress Index 2)
# S1 = Bande B11, G = Bande B3
dswi2 <- raster_image$B11 / raster_image$B3

# DSWI3 (Disease-Water Stress Index 3)
# S1 = Bande B11, R = Bande B4
dswi3 <- raster_image$B11 / raster_image$B4

# DSWI4 (Disease-Water Stress Index 4)
# G = Bande B3, R = Bande B4
dswi4 <- raster_image$B3 / raster_image$B4

# DSWI5 (Disease-Water Stress Index 5)
# N = Bande B8, G = Bande B3, S1 = Bande B11, R = Bande B4
dswi5 <- (raster_image$B8 + raster_image$B3) / (raster_image$B11 + raster_image$B4)

# DVI (Difference Vegetation Index)
# N = Bande B8, R = Bande B4
dvi <- raster_image$B8 - raster_image$B4
